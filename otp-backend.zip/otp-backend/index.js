// index.js
const express = require("express");
const axios = require("axios");
const dotenv = require("dotenv");

dotenv.config(); // Load .env variables

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware to parse JSON
app.use(express.json());

// Basic route
app.get("/", (req, res) => {
  res.send("✅ OTP backend is running!");
});

// Route to send OTP
app.post("/send-otp", async (req, res) => {
  const { phone } = req.body;

  if (!phone) {
    return res.status(400).json({ error: "Phone number is required." });
  }

  const otp = Math.floor(100000 + Math.random() * 900000); // 6-digit code
  const message = `Your BetFlip OTP code is: ${otp}`;

  try {
    const response = await axios.post("https://sms.afromessage.com/api/send", {
      to: phone,
      message,
    }, {
      headers: {
        "Authorization": `Bearer ${process.env.AFROMESSAGE_API_KEY}`,
        "Content-Type": "application/json"
      }
    });

    console.log("SMS response:", response.data);
    return res.status(200).json({ success: true, otp });
  } catch (error) {
    console.error("Error sending OTP:", error.message);
    return res.status(500).json({ error: "Failed to send OTP." });
  }
});

// Start the server
app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
});
